package Project;

import java.util.*;
import java.io.*;
import java.lang.*;

public class LoadAssignments 
{
	public static String oldTitle [] = new String[20];
	public static String oldDue [] = new String[20];
	
	private static PrintWriter store;
	private static PrintWriter store1;
	
	public static String newTitle [] = new String[20];
	public static String newDue [] = new String[20];
	
	public void retrieve () 
	{
		while (true) 
		{
			try 
			{
				Scanner imprt = new Scanner (new File("assign_title.txt"));
				int j = 0;
				while (imprt.hasNext()) 
				{
					oldTitle[j] = imprt.nextLine();
					j++;
				}
				
				imprt.close();
				break;
			}
			catch (FileNotFoundException e) 
			{
				
				File data = new File ("assign_title.txt");
				while(true) {
					try {
						data.createNewFile();
						break;
					}
					catch (IOException exc) {
						System.out.println(exc);
					}
				}
				
			}
		}
		
		while (true) 
		{
			try 
			{
				Scanner impr = new Scanner (new File("assign_due.txt"));
				int j = 0;
				while (impr.hasNext()) 
				{
					oldDue[j] = impr.nextLine();
					j++;
				}
				
				impr.close();
				break;
			}
			catch (FileNotFoundException e) 
			{
				
				File dat = new File ("assign_due.txt");
				while(true) {
					try {
						dat.createNewFile();
						break;
					}
					catch (IOException exc) {
						System.out.println(exc);
					}
				}
				
			}
		}
		add();
	}
	
	public void add() 
	{
		for (int a = 0; a < oldTitle.length; a++) 
		{
			String title = oldTitle[a];
			
			if (title != null)
			{
				String due[] = new String [2];
				due = oldDue[a].split(",", 2);
				
				TableV add = new TableV();
				
			
					add.assign(title, due[0], due[1]);
		
				AssignScreen.setQ(1);
			}
		}
	}
	
	public static void upload() 
	{
		newTitle = TableV.getAssignList();
		
		newDue = TableV.getDateList();
		try
		{
			store = new PrintWriter("assign_title.txt");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		for (int j = 0; j < newTitle.length; j++) 
		{
			String a = newTitle[j];
			if (a != null)
			{
				
				store.println(a);
			}
			else if (a == null) 
			{
				continue;
			}
		}
		store.close();
		
		try
		{
			store1 = new PrintWriter("assign_due.txt");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		for (int j = 0; j < newDue.length; j++) 
		{
			String a = newDue[j];
			if (a != null)
			{
				store1.println(a);
				
			}
			else if (a == null) 
			{
				continue;
			}
		}
		
		store1.close();
		System.exit(0);
	}
	
	
	
	
	
	
	
	
	
	
	
}
