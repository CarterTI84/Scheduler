package Project;

import java.util.*;
public class Assignment{
 
  public static int dateYear;
  public static int dateMonth;
  public static int dateDay;
  
  private static int dayCount;
  public String n;
  static Calendar q = Calendar.getInstance();
  static Calendar d = Calendar.getInstance();
  
  
		
  
 
  

  public Assignment(String name, int year, int month, int day)
    {
      n = name;
      dateYear = year;
      dateMonth = month -1 ;
      dateDay = day;
    }

  public String returnName()
    {
      return n;
    }

  public int DueYear()
    {
      return dateYear;
    }
  
  public int DueMonth()
    {
      return dateMonth;
    }

  public int DueDay()
    {
      return dateDay;
    }

  
  public int daysLeft()
    {
	  d.set(dateYear,dateMonth, dateDay);
	  int o = d.compareTo(q);
	  System.out.println(o);
	  
      dayCount = 0;
       
      if (d.get(Calendar.MONTH) < q.get(Calendar.MONTH))
      {
    	  dayCount = -1;
    	  return dayCount;
      }
      
      else if (d.get(Calendar.MONTH) >= q.get(Calendar.MONTH))
      {
    	  if(q.get(Calendar.MONTH ) == d.get(Calendar.MONTH)) 
    	  {
    		  if (d.get(Calendar.DAY_OF_MONTH) < q.get(Calendar.DAY_OF_MONTH) )
    		  {
    			  System.out.println("?");
    			  dayCount = -1;
    			  return dayCount;
    		  }
    		  dayCount = 1;
    		  return dayCount;
    		  
    	  }
    	  
      }
	return dayCount;
      
      
      
      
      
      
      /*
      if (d.get(Calendar.MONTH) - q.get(Calendar.MONTH) >= 0)
        {
            if (q.get(Calendar.MONTH) == 0||q.get(Calendar.MONTH) == 2||q.get(Calendar.MONTH) == 4||q.get(Calendar.MONTH) == 6||q.get(Calendar.MONTH) == 7||q.get(Calendar.MONTH) == 9||q.get(Calendar.MONTH) == 11)
            {
            	int dd = (31 - q.get(Calendar.DAY_OF_MONTH) + d.get(Calendar.DAY_OF_MONTH));
              dayCount = dayCount + dd;
            }

            else if (q.get(Calendar.MONTH) == 3||q.get(Calendar.MONTH) == 5||q.get(Calendar.MONTH) == 8||q.get(Calendar.MONTH) == 10)
            {
              int ddd = (30 - q.get(Calendar.DAY_OF_MONTH)) + d.get(Calendar.DAY_OF_MONTH);
              dayCount = dayCount + ddd;              
            }

            else
            {
              if (q.get(Calendar.YEAR)%4 == 0)
              {
                int dddd = (29 - q.get(Calendar.DAY_OF_MONTH)) + d.get(Calendar.DAY_OF_MONTH);
                dayCount = dayCount + dddd;   
              }

              else
              {
                int ddddd = (28 - q.get(Calendar.DAY_OF_MONTH)) + d.get(Calendar.DAY_OF_MONTH);
                dayCount = dayCount + ddddd;
              }
            }
        }
        else 
        {
          dayCount = dayCount+ (d.get(Calendar.DAY_OF_MONTH) - q.get(Calendar.DAY_OF_MONTH));
        }
      dayCount = dayCount;
      return dayCount;
      */
    }

public static void setDayCount(int dayCount) {
	Assignment.dayCount = dayCount;
}



}

