package Project;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.*;
import java.util.*;
import java.lang.*;

public class Timetask extends TimerTask
{
	public static TableV a = new TableV();
	
	//public static String assignList[]  = new String[20];
	//public static String dateList[]  = new String[20];
	
	public void run() 
	{
		
		//assignList = TableV.getAssignList();
		//dateList = TableV.getDateList();
		
		//checkContents();
		System.out.println("check");
		
				
	}
	/*
	public void checkContents()
	{
		for (int a = 0; a < assignList.length; a++) 
		{
			String title = assignList[a];
			
			if (title != null)
			{
				String due[] = dateList[a].split(",",2);
				
				int month = Integer.parseInt(due[0]);
				int day = Integer.parseInt(due[1]);
				
				Assignment getDue = new Assignment(title, 2020, month, day);
				
				int duetime = Assignment.daysLeft();
				System.out.println(duetime);
				
				if (duetime > 0) 
				{
					String dueTime = Integer.toString(duetime) + "day(s) left.";
					
				}
				else if (duetime == 0) 
				{
					String dueTime = "Due today!";
					
				}
				else
				{
					String dueTime = "Overdue!";
					
				}
			}
		}
	}*/
}
	/*
	public void view () 
	{			
		Stage window1 = null;
		try {
			window1 = new Stage();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		window1.setOnCloseRequest(e -> 
		{ 
			e.consume(); 
			LoadAccs.upload(Start.acc);
		});
		
		TableView<TableContents> table = new TableView();
		table.setMaxHeight(200);
		//First column
		TableColumn<TableContents, String> nameAssi = new TableColumn<>("Assignments:");
		nameAssi.setMinWidth(200);
		nameAssi.setCellValueFactory(new PropertyValueFactory<>("title"));
		
		//Second column
		TableColumn<TableContents, String> dueDate = new TableColumn<>("Due in:");
		dueDate.setMinWidth(200);
		dueDate.setCellValueFactory(new PropertyValueFactory<>("date"));
		
		table.setItems(getContents());
		table.getColumns().addAll(nameAssi, dueDate);
		
		Button start = new Button("Start");
		start.setMinWidth(100);
		start.setOnAction(e -> 
		{
			TimeR.run();
		});
		
		Button back = new Button("Back");
		back.setOnAction(e -> 
		{
			
			AssignScreen.start();
		});
		
		
		VBox layout = new VBox (10);
		layout.getChildren().addAll(table, start, back);
		
		Scene scene1 = new Scene(layout, 400, 400);
		window1.setScene(scene1);
		window1.show();
	}
	

	
	
	public static int o = 0;
	public TimeR timer = new TimeR();
}
*/
