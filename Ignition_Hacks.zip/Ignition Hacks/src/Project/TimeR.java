package Project;

import java.util.*;
import java.lang.*;
public class TimeR 
{
	/*
	public static void run() 
	{
		Timer timer = new Timer();
		int time = (1) * 1000 * (10);
		timer.schedule(new Timetask(), time, time);
	}
	*/
}
