package Project;

import java.util.*;
import java.io.*;


public class LoadAccs {
	
	public static String existingAcc[] = new String[2];
	private static PrintWriter store;
	
	
	public static void load () 
	{
		
		
		while (true) 
		{
			try 
			{
				Scanner imprt = new Scanner (new File("acc.txt"));
				int j = 0;
				while (imprt.hasNext()) 
				{
					existingAcc[j] = imprt.nextLine();
					j++;
				}
				
				imprt.close();
				break;
			}
			catch (FileNotFoundException e) 
			{
				
				File data = new File ("acc.txt");
				while(true) {
					try {
						data.createNewFile();
						break;
					}
					catch (IOException exc) {
						System.out.println(exc);
					}
				}
				
			}
		}
		
		
	}
	
	public static void upload (String [] list) 
	{
		try
		{
			store = new PrintWriter("acc.txt");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		for (int j = 0; j < list.length; j++) 
		{
			String a = list[j];
			if (a != null)
			{
				store.println(a);
			}
			else if (a == null) 
			{
				continue;
			}
		}
		store.close();
		LoadAssignments.upload();
		
	}
}
	 