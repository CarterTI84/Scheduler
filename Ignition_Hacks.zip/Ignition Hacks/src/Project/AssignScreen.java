package Project;

import java.awt.Color;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.*;
import javafx.scene.text.Font;

public class AssignScreen  
{
	public static Stage window;
	
	public static void start()   
	{
		TableV transfer = new TableV();
		
		Stage w = new Stage();
		window = w;
		
		window.setTitle("Schedule Planner");
		window.setOnCloseRequest(e -> 
		{ 
			e.consume(); 
			LoadAccs.upload(Start.acc);
		});
		
		VBox layout = new VBox(20);
		layout.setAlignment(Pos.CENTER);
		
		Button newA = new Button ("Create New Assignment");
		newA.setOnAction(e -> {
			window.hide();
			createAssign();
		});
		
		
		Button viewAssi = new Button ("View All Assignments");
		viewAssi.setOnAction(e -> AssignScreen.transfer());
		
		layout.getChildren().addAll(newA, viewAssi);
		
		Scene scene = new Scene(layout, 350, 300);
		window.setScene(scene);
		window.show();
		
	}
	
	public static void createAssign () 
	{
		Stage window = new Stage ();
		window1 = window;
		
		window1.setTitle("Create Assignment");
		window1.setOnCloseRequest(e -> 
		{ 
			e.consume(); 
			LoadAccs.upload(Start.acc);
		});
		
		GridPane layout = new GridPane();
		layout.setPadding(new Insets(20,20,20,20));
		layout.setVgap(10);
		layout.setHgap(10);
		
		Label label1 = new Label ("Title of the assignment:");
		GridPane.setConstraints(label1, 0, 0);
		
		TextField title = new TextField();
		title.setPromptText("title");
		GridPane.setConstraints(title, 0, 1);
		
		Label dateLabel = new Label("Due Date:");
		GridPane.setConstraints(dateLabel, 0, 3);
		
		Label month = new Label("Month:");
		GridPane.setConstraints(month, 0, 4);
		
		TextField monthV = new TextField();
		monthV.setPromptText("00");
		GridPane.setConstraints(monthV, 1, 4);
		
		Label day = new Label("Day:");
		GridPane.setConstraints(day, 0, 5);
		
		TextField dayV = new TextField();
		dayV.setPromptText("00");
		GridPane.setConstraints(dayV, 1, 5);
		
		Button confirm = new Button ("Done");
		confirm.setMinWidth(100);
		GridPane.setConstraints(confirm, 0, 6);
		confirm.setOnAction(e -> { process(title.getText(), monthV.getText(), dayV.getText());});
		
		Button back = new Button("Back");
		GridPane.setConstraints(back, 0, 7);
		back.setOnAction(e -> 
		{
			window1.hide();
			start();
		});
		
		layout.getChildren().addAll(label1, title, dateLabel, month, monthV, day, dayV, confirm, back);
		
		Scene scene = new Scene(layout, 500, 400);
		
		window1.setScene(scene);
		window1.show();
	}
	
	public static void process (String t, String m, String d) 
	{
		int j = 0;
		int g = 0;
		int p = 0;
		String title = t;
		if (title.equals("")) 
		{
			Alert.display("Error", "Title Invalid.");
		}
		else
			j++;
		
	
			try
			{
				int month = Integer.parseInt(m);
				int day = Integer.parseInt(d);
				if (month < 1 || month > 12)
				{
					Alert.display("Error", "Due Date Invalid.");
				}
				else
				{
					g++;
				}
				
				if ( day < 1 || day > 31) 
				{
					Alert.display("Error", "Due Date Invalid.");
				}
				else if((day > 29 && month == 2) || (day > 30 && month == 4) 
						|| (day > 30 && month == 6) || (day > 30 && month == 9) || (day > 30 && month == 11)) 
				{
					Alert.display("Error", "Due Date Invalid.");
				}
				else
				{
					p++;
				}
				
								
			}
			catch (NumberFormatException e) 
			{
				Alert.display("Error", "Due Date Invalid.");
			}
			
		
		if (j > 0 && p > 0 && g > 0) {
		
			
			TableV transfer = new TableV();
			transfer.assign(t, m, d);
			q++;
			window1.hide();
			AssignScreen.start();
			
		}
		
	}
	
	public static void transfer () 
	{
		if (q > 0)
		{
			TableV transfer = new TableV();
			window.hide();
			transfer.view();
		}
		else
			Alert.display("Error", "No Assignments Available.");
		
	}
	public static void setQ (int a) 
	{
		q = a;
	}
	
	public static Stage window1;
	private static int q = 0;

}
