package Project;



import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.*;
import javafx.scene.canvas.*;
import javafx.scene.layout.Background;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import java.lang.reflect.Array;
import javafx.scene.Group;


public class Start extends Application
{
	static Stage window;
	public static String parentEmail;
	public static String acc [] = new String [2] ;
	Button loginButton, newAcc;
	
	public static void main (String [] args) 
	{
		LoadAssignments loadass = new LoadAssignments();
		loadass.retrieve();
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		LoadAccs.load();
		acc = LoadAccs.existingAcc;
		
		window = primaryStage;
		window.setTitle("Schedule Planner");
		window.setOnCloseRequest(e -> 
		{ 
			e.consume(); 
			LoadAccs.upload(acc);
		});
		
		
		GridPane layout = new GridPane();
		layout.setPadding(new Insets(20,20,20,20));
		layout.setVgap(10);
		layout.setHgap(10);
		
		
		
		Label user = new Label("Email:");
		GridPane.setConstraints(user, 0, 0);
		
		Label pass = new Label ("Password:");
		GridPane.setConstraints(pass, 0, 2);
		
		TextField login = new TextField ();
		login.setPromptText("email");
		GridPane.setConstraints(login, 0, 1);
		
		PasswordField password = new PasswordField ();
		password.setPromptText("password");
		
		GridPane.setConstraints(password, 0, 3);
		
		loginButton = new Button ("Login");
		GridPane.setConstraints(loginButton, 0, 4);
		loginButton.setOnAction(e ->
		{
			verify(login.getText(), password.getText());
		});
		
		newAcc = new Button("Create Account");
		GridPane.setConstraints(newAcc, 0, 5);
		newAcc.setOnAction(e ->{
			if (acc[0] != null) 
			{
				Alert.display("Error", "Account already exists.");
			}
			else if (acc[0] == null) 
			{
				window.hide();
				create();
			}
		});
		
		layout.getChildren().addAll(user, pass, login, password, loginButton, newAcc);
		
		
		Scene scene = new Scene (layout, 400, 300);
		
		window.setScene(scene);
		window.show();
	}
	
	public static void verify (String username, String password) 
	{
		String u = username;
		String p = password;
		if (u.equals(acc[0]) && p.equals(acc[1]))
		{
			parentEmail = u;
			
			window.hide();
			//Go to next screen.
			AssignScreen.start();
			
		}
		else 
		{
			Alert.display("Error", "Username or Password is Invalid.");
		}
	}
	
	public static void create ()
	{
		Stage windowCreate = new Stage();
		windowCreate.setTitle("");
		window.setOnCloseRequest(e -> 
		{ 
			e.consume(); 
			LoadAccs.upload(acc);
		});
		
		GridPane layout = new GridPane();
		layout.setPadding(new Insets(20,20,20,20));
		layout.setVgap(10);
		layout.setHgap(10);
		
		Label user = new Label("Enter Email:");
		GridPane.setConstraints(user, 0, 0);
		
		
		Label pass = new Label ("Enter Password:");
		GridPane.setConstraints(pass, 0, 2);
		
		TextField login = new TextField ();
		login.setPromptText("email");
		GridPane.setConstraints(login, 0, 1);
		
		
		PasswordField password = new PasswordField ();
		password.setPromptText("password");
		
		GridPane.setConstraints(password, 0, 3);
		
		Button create = new Button ("Create");
		GridPane.setConstraints(create, 0, 4);
		
		create.setOnAction(e -> 
		{
			if (login.getText().equals("") || password.getText().equals(""))
			{
				Alert.display("Error", "Invalid.");
			}
			else
			{
				acc[0] = login.getText();
				acc[1] = password.getText();
				windowCreate.hide();
				//Go to next screen.
				AssignScreen.start();
			}
		});
		
		layout.getChildren().addAll(user, pass, login, password, create);
		
		Scene scene = new Scene (layout, 400, 300);
		
		windowCreate.setScene(scene);
		windowCreate.show();
	}	
}
