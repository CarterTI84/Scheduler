package Project;

public class FakeStart {
	public static void main(String args[]) {
		Start.main(args);
	}
}
