package Project;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.*;
import java.util.*;
import java.lang.Object.*;
import javafx.collections.*;
import java.io.*;
import java.lang.reflect.Array;
import javafx.scene.control.cell.PropertyValueFactory;
import java.lang.*;

public class TableV 
{
	
	private static String title;
	private static String date;
	public static boolean check = true;
	static String assignList[]  = new String[20];
	static String dateList[]  = new String[20];
	public void assign (String t, String m, String d) 
	{
		title = t;
		
		date = m + "," + d;
		
		for (int j = 0; j < (assignList.length); j++) 
		{
			String a = assignList[j];
			
			if ((a == null))
			{
				assignList[j] = title;
				dateList[j] = date;
				break;
			}
			if (!(a== null))
			{
				continue;
			}
		}
		//if (int a == 1) 
		{
			
		}
		
	}
	
	public static String[] getAssignList() {
		return assignList;
	}

	public static String[] getDateList() {
		return dateList;
	}

	public static ObservableList<TableContents> getContents()
	{
		ObservableList<TableContents> addAssi = FXCollections.observableArrayList();
		String mon = "";
	
		for (int a = 0; a < assignList.length; a++) 
		{
			String title = assignList[a];
			
			if (title == null)
			{
				continue;
			}
			else if (title != null)
			{
				String due[] = dateList[a].split(",", 2);
				
				
				String he = due[0];
				System.out.println(due[0]);
				
				
				
					int month = Integer.parseInt(due[0]);
					int day = Integer.parseInt(due[1]);
					
					Assignment getDue = new Assignment(title, 2020, month, day);
					
					int ch = getDue.daysLeft();
					if (ch < 0) 
					{
						he = ".";				
					}
					switch (he)
					{
					    case ".":
					    		mon = "Overdue!";
					    		break;
						case "1": 
								mon = "January " + due[1];
								break;
						case "2":
								mon = "February " + due[1];
								break;
						case "3":
								mon = "March " + due[1];
								break;
						case "4":
								mon = "April " + due[1];
								break;
						case "5":
								mon = "May " + due[1];
								break;
						case "6":
								mon = "June " + due[1];
								break;
						case "7":
								mon = "July " + due[1];
								break;
						case "8":
								mon = "August " + due[1];
								break;
						case "9":
								mon = "September " + due[1];
								break;
						case "10":
								mon = "Octobor " + due[1];
								break;
						case "11":
								mon = "November " + due[1];
								break;
						case "12":
								mon = "December " + due[1];
								break;
						default:
								mon = "n/a";
								continue;
					}
				 
					System.out.println(mon);
					addAssi.add(new TableContents(title, mon));
				
				/*
				int month = Integer.parseInt(due[0]);
				int day = Integer.parseInt(due[1]);
				
				Assignment getDue = new Assignment(title, 2020, month, day);
				
				int duetime = getDue.daysLeft();
				System.out.println(duetime);
				
				
				if (duetime > 0) 
				{
					String dueTime = Integer.toString(duetime) + " day(s) left.";
					addAssi.add(new TableContents(title, dueTime));
				}
				else if (duetime == 0) 
				{
					String dueTime = "Due today!";
					addAssi.add(new TableContents(title, dueTime));
				}
				else
				{
					String dueTime = "Overdue!";
					addAssi.add(new TableContents(title, dueTime));
				}
			*/
			}
			
			
		}
	
		
		return addAssi;
	}
	
	public static Stage window;
	public Stage window1;
	public static TableView<TableContents> table;
	public static TableColumn<TableContents, String> nameAssi;
	public static TableColumn<TableContents, String> dueDate;
	
	public static void view () 
	{	
		
			window = new Stage();
			window.setTitle("Schedule Planner");
			window.setOnCloseRequest(e -> 
			{ 
				e.consume(); 
				LoadAccs.upload(Start.acc);
			});
			
			table = new TableView();
			table.setMaxHeight(200);
			//First column
			nameAssi = new TableColumn<>("Assignments:");
			nameAssi.setMinWidth(200);
			nameAssi.setCellValueFactory(new PropertyValueFactory<>("title"));
			
			
			//Second column
			dueDate = new TableColumn<>("Due on:");
			dueDate.setMinWidth(200);
			dueDate.setCellValueFactory(new PropertyValueFactory<>("date"));
			
			table.setItems(getContents());
			table.getColumns().addAll(nameAssi, dueDate);
			
			
			
			
				Button start = new Button("Start Timer");
				start.setMinWidth(100);
				start.setOnAction(e -> 
				{
					//TimeR.run();
					check = false;
					window.hide();
					view();
				});
				Button refresh = new Button("Refresh");
				refresh.setMinWidth(100);
				refresh.setOnAction(e -> 
				{
					window.hide();
					TableV.view();
					Assignment.setDayCount(0);
				});
				
				Button back = new Button("Back");
				back.setOnAction(e -> 
				{
					window.hide();
					AssignScreen.start();
				});
				
				Button delete = new Button("Remove Assignment");
				delete.setOnAction(e -> 
				{
					deleteAssignment();
				});
				
				
				VBox layout = new VBox (10);
				layout.getChildren().addAll(table, delete, back);
				layout.setPadding(new Insets(20,20,20,20));
				
				Scene scene = new Scene(layout, 441, 400);
				window.setScene(scene);
				window.show();
			/*
				Button refresh = new Button("Refresh");
				refresh.setMinWidth(100);
				refresh.setOnAction(e -> 
				{
					window.close();
					view();
					
				});
				
				Button delete = new Button("Remove Assignment");
				delete.setOnAction(e -> 
				{
					//deleteAssignment();
				});
				
				Button back = new Button("Back");
				back.setOnAction(e -> 
				{
					window.hide();
					AssignScreen.start();
				});
				
				
				VBox layout = new VBox (10);
				layout.getChildren().addAll(table, refresh, delete, back);
				
				Scene scene = new Scene(layout, 400, 400);
				window.setScene(scene);
				window.show();
				*/
			
			
		
	
		
	}
	
	public static void deleteAssignment()
	{
		Stage win = new Stage();
		
		Label label = new Label("Enter password:");
		
		PasswordField password = new PasswordField();
		password.setPromptText("password");
		
		Button confirm = new Button("Confirm");
		confirm.setOnAction(e ->
		{
			String pass = Start.acc[1];
			
			if (pass.equals(password.getText())) 
			{
				ObservableList<TableContents> selectedAssi, allAssi;
				allAssi = table.getItems();
				
				selectedAssi = table.getSelectionModel().getSelectedItems();
				selectedAssi.forEach(allAssi::remove);
				
				for (int j = 0; j < assignList.length; j++) 
				{
					for (int l = 0; l < 2; l++) 
					{
						if (l == 0)
						{
							assignList[j] = (String) nameAssi.getCellData(j);
						}
						else if (l == 1) 
						{
							String k = (String) dueDate.getCellData(j);
							String m [] = new String[2];
							String p = "";
							
							if (m[0] == null) 
							{
								continue;
							}
							else if(m[0].equals("January")) 
							{
								p = "1";
							}
							else if (m[0].equals("February")) 
							{
								p = "2";
							}
							else if (m[0].equals("March")) 
							{
								p = "3";
							}
							else if (m[0].equals("April")) 
							{
								p = "4";
							}
							else if (m[0].equals("May")) 
							{
								p = "5";
							}
							else if (m[0].equals("June")) 
							{
								p = "6";
							}
							else if (m[0].equals("July")) 
							{
								p = "7";
							}
							else if (m[0].equals("August")) 
							{
								p = "8";
							}
							else if (m[0].equals("September")) 
							{
								p = "9";
							}
							else if (m[0].equals("Octobor")) 
							{
								p = "10";
							}
							else if (m[0].equals("November")) 
							{
								p = "11";
							}
							else if (m[0].equals("December")) 
							{
								p = "12";
							}
							else
								p = "-1";
							dateList[j] = p + "," + m[1]; 
							
						}
					}
				}
				System.out.println(nameAssi.getTableView().getItems().size());
				
				for (int p = nameAssi.getTableView().getItems().size(); p < assignList.length;p++) 
				{
					assignList[p] = null;
				}
				
				for (int p = dueDate.getTableView().getItems().size(); p < dateList.length;p++) 
				{
					dateList[p] = null;
				}
				
				win.hide();
				
			}
			else
			{
				Alert.display("Error", "Password Invalid.");
			}
		});
		
		VBox layout = new VBox(10);
	
		layout.setAlignment(Pos.CENTER);
		layout.setPadding(new Insets(20,20,20,20));
		layout.getChildren().addAll(label, password, confirm);
		
		Scene scene = new Scene(layout, 300, 200);
		win.setScene(scene);
		win.show();
		
				
		
	}

	
	
	public static int o = 0;
	public TimeR timer = new TimeR();
	
	
}
